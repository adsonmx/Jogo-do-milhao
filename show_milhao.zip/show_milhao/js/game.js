// Banco de perguntas
const bancoPerguntas = [
    // Geografia
    {
        categoria: "Geografia",
        pergunta: "Qual é a capital do Brasil?",
        opcoes: ["São Paulo", "Rio de Janeiro", "Brasília", "Salvador"],
        correta: 2,
        valor: 1000
    },
    {
        categoria: "Geografia",
        pergunta: "Qual o maior país da América do Sul?",
        opcoes: ["Argentina", "Brasil", "Colômbia", "Peru"],
        correta: 1,
        valor: 2000
    },
    {
        categoria: "Geografia",
        pergunta: "Qual oceano banha o Brasil?",
        opcoes: ["Pacífico", "Índico", "Atlântico", "Ártico"],
        correta: 2,
        valor: 3000
    },
    {
        categoria: "Geografia",
        pergunta: "Qual a montanha mais alta do mundo?",
        opcoes: ["Monte Everest", "K2", "Aconcágua", "Monte McKinley"],
        correta: 0,
        valor: 4000
    },
    
    // Matemática
    {
        categoria: "Matemática",
        pergunta: "Quanto é 7 x 8?",
        opcoes: ["48", "56", "64", "72"],
        correta: 1,
        valor: 1000
    },
    {
        categoria: "Matemática",
        pergunta: "Qual a raiz quadrada de 144?",
        opcoes: ["10", "11", "12", "13"],
        correta: 2,
        valor: 2000
    },
    {
        categoria: "Matemática",
        pergunta: "Quanto é 15% de 200?",
        opcoes: ["15", "30", "45", "60"],
        correta: 1,
        valor: 3000
    },
    
    // Literatura
    {
        categoria: "Literatura",
        pergunta: "Quem escreveu 'Dom Casmurro'?",
        opcoes: ["José de Alencar", "Machado de Assis", "Carlos Drummond", "Clarice Lispector"],
        correta: 1,
        valor: 1000
    },
    {
        categoria: "Literatura",
        pergunta: "Qual o livro mais vendido do mundo?",
        opcoes: ["Dom Quixote", "Bíblia", "O Pequeno Príncipe", "Harry Potter"],
        correta: 1,
        valor: 4000
    },
    
    // Ciências
    {
        categoria: "Ciências",
        pergunta: "Qual o maior planeta do sistema solar?",
        opcoes: ["Marte", "Saturno", "Júpiter", "Urano"],
        correta: 2,
        valor: 1000
    },
    {
        categoria: "Ciências",
        pergunta: "Qual animal é conhecido como 'Rei da Selva'?",
        opcoes: ["Tigre", "Leão", "Elefante", "Girafa"],
        correta: 1,
        valor: 2000
    },
    {
        categoria: "Ciências",
        pergunta: "Quantos ossos tem o corpo humano adulto?",
        opcoes: ["206", "208", "210", "212"],
        correta: 0,
        valor: 3000
    },
    
    // História
    {
        categoria: "História",
        pergunta: "Em que ano o homem pisou na Lua?",
        opcoes: ["1965", "1969", "1972", "1975"],
        correta: 1,
        valor: 1000
    },
    {
        categoria: "História",
        pergunta: "Quem descobriu o Brasil?",
        opcoes: ["Dom Pedro I", "Pedro Álvares Cabral", "Cristóvão Colombo", "Vasco da Gama"],
        correta: 1,
        valor: 2000
    },
    {
        categoria: "História",
        pergunta: "Em que ano terminou a Segunda Guerra Mundial?",
        opcoes: ["1944", "1945", "1946", "1947"],
        correta: 1,
        valor: 4000
    },
    
    // Cultura Geral
    {
        categoria: "Cultura Geral",
        pergunta: "Qual a cor do cavalo branco de Napoleão?",
        opcoes: ["Preto", "Marrom", "Branco", "Cinza"],
        correta: 2,
        valor: 5000
    },
    {
        categoria: "Cultura Geral",
        pergunta: "Quem pintou a Mona Lisa?",
        opcoes: ["Van Gogh", "Picasso", "Leonardo da Vinci", "Michelangelo"],
        correta: 2,
        valor: 3000
    },
    {
        categoria: "Cultura Geral",
        pergunta: "Qual o nome do personagem principal do filme 'Titanic'?",
        opcoes: ["Jack", "Rose", "Caledon", "Ruth"],
        correta: 0,
        valor: 2000
    },
    {
        categoria: "Cultura Geral",
        pergunta: "Quantas cordas tem um violão clássico?",
        opcoes: ["4", "5", "6", "7"],
        correta: 2,
        valor: 3000
    }
];

// Estado do jogo
let jogoAtivo = false;
let perguntasSelecionadas = [];
let perguntaAtual = 0;
let pontuacao = 0;
let respostaConfirmada = false;
let indiceSelecionado = -1;

// Funções auxiliares
function selecionarPerguntasAleatorias(quantidade = 5) {
    const perguntasEmbaralhadas = [...bancoPerguntas].sort(() => Math.random() - 0.5);
    const selecionadas = perguntasEmbaralhadas.slice(0, quantidade);
    
    return selecionadas.map((pergunta, index) => ({
        ...pergunta,
        fase: index + 1,
        valor: Math.pow(10, index) * 1000
    }));
}

// Funções principais do jogo
function iniciarJogo() {
    document.getElementById('startScreen').style.display = 'none';
    document.getElementById('gameScreen').style.display = 'block';
    
    jogoAtivo = true;
    perguntaAtual = 0;
    pontuacao = 0;
    respostaConfirmada = false;
    indiceSelecionado = -1;
    
    perguntasSelecionadas = selecionarPerguntasAleatorias(5);
    
    carregarPergunta();
}

function carregarPergunta() {
    const pergunta = perguntasSelecionadas[perguntaAtual];
    document.getElementById('faseAtual').textContent = `Fase ${pergunta.fase}`;
    document.getElementById('pontuacao').textContent = `R$ ${pontuacao.toLocaleString()}`;
    document.getElementById('categoria').textContent = pergunta.categoria;
    document.getElementById('pergunta').textContent = pergunta.pergunta;
    document.getElementById('instrucao').textContent = "Clique em uma alternativa (pode trocar antes de confirmar)";
    
    const opcoesDiv = document.getElementById('opcoes');
    opcoesDiv.innerHTML = '';
    
    const letras = ['A', 'B', 'C', 'D'];
    pergunta.opcoes.forEach((opcao, index) => {
        const botao = document.createElement('div');
        botao.className = 'opcao';
        botao.innerHTML = `<span class="letra-opcao">${letras[index]}</span> ${opcao}`;
        botao.onclick = () => selecionarOpcao(index);
        opcoesDiv.appendChild(botao);
    });

    document.getElementById('confirmarBtn').disabled = true;
    document.getElementById('cancelarBtn').style.display = 'none';
    document.getElementById('proximaBtn').style.display = 'none';
    respostaConfirmada = false;
    indiceSelecionado = -1;
}

function selecionarOpcao(index) {
    if (respostaConfirmada || !jogoAtivo) return;

    if (indiceSelecionado === index) return;

    const opcoes = document.querySelectorAll('.opcao');
    opcoes.forEach(opcao => {
        opcao.classList.remove('selecionada');
    });

    opcoes[index].classList.add('selecionada');
    indiceSelecionado = index;
    
    document.getElementById('confirmarBtn').disabled = false;
    document.getElementById('cancelarBtn').style.display = 'block';
    document.getElementById('instrucao').textContent = "Alternativa selecionada. Confirme ou cancele para trocar.";
}

function cancelarSelecao() {
    if (respostaConfirmada || !jogoAtivo) return;

    const opcoes = document.querySelectorAll('.opcao');
    opcoes.forEach(opcao => {
        opcao.classList.remove('selecionada');
    });

    indiceSelecionado = -1;
    
    document.getElementById('confirmarBtn').disabled = true;
    document.getElementById('cancelarBtn').style.display = 'none';
    document.getElementById('instrucao').textContent = "Seleção cancelada. Escolha uma nova alternativa.";
}

function confirmarResposta() {
    if (indiceSelecionado === -1 || respostaConfirmada || !jogoAtivo) return;

    const pergunta = perguntasSelecionadas[perguntaAtual];
    const opcoes = document.querySelectorAll('.opcao');
    
    respostaConfirmada = true;
    
    document.getElementById('cancelarBtn').style.display = 'none';
    
    opcoes[pergunta.correta].classList.add('correta');
    
    if (indiceSelecionado === pergunta.correta) {
        pontuacao += pergunta.valor;
        document.getElementById('pontuacao').textContent = `R$ ${pontuacao.toLocaleString()}`;
        document.getElementById('instrucao').textContent = "Resposta correta! Parabéns!";
        
        if (perguntaAtual === perguntasSelecionadas.length - 1) {
            setTimeout(() => {
                alert(`PARABÉNS! Você chegou ao fim do jogo!\nPontuação final: R$ ${pontuacao.toLocaleString()}`);
                mostrarResultado('sucesso', `VOCÊ É UM MILIONÁRIO! 🎉\n\nPontuação final: R$ ${pontuacao.toLocaleString()}`);
            }, 500);
        } else {
            document.getElementById('proximaBtn').style.display = 'block';
        }
    } else {
        opcoes[indiceSelecionado].classList.add('errada');
        jogoAtivo = false;
        document.getElementById('instrucao').textContent = "Resposta errada! Game Over!";
        
        setTimeout(() => {
            mostrarResultado('fracasso', `GAME OVER! Você perdeu! 💔\n\nPontuação final: R$ ${pontuacao.toLocaleString()}`);
        }, 500);
    }

    document.getElementById('confirmarBtn').disabled = true;
    opcoes.forEach(opcao => {
        opcao.classList.add('disabled');
    });
}

function proximaPergunta() {
    if (perguntaAtual < perguntasSelecionadas.length - 1) {
        perguntaAtual++;
        carregarPergunta();
    }
}

function mostrarResultado(tipo, mensagem) {
    const gameScreen = document.getElementById('gameScreen');
    const resultadoDiv = document.createElement('div');
    resultadoDiv.className = `resultado ${tipo}`;
    resultadoDiv.style.whiteSpace = 'pre-line';
    resultadoDiv.textContent = mensagem;
    
    const voltarBtn = document.createElement('button');
    voltarBtn.className = 'start-btn';
    voltarBtn.textContent = 'JOGAR NOVAMENTE';
    voltarBtn.onclick = () => {
        document.location.reload();
    };
    
    gameScreen.innerHTML = '';
    gameScreen.appendChild(resultadoDiv);
    gameScreen.appendChild(voltarBtn);
}